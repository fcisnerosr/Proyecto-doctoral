function [T_gamma, T_beta] = TransfM3Dframe_AG(j, elements, nodes, L, CX, CY, CZ, CXY)
    % % Gamma para elementos horizontales (vigas)
    % gammavigas = [  0               0           CZ; 
    %                 CZ*sinalpha     cosalpha    0;
    %                 -CZ*cosalpha    sinalpha    0];

    % Gamma para elementos inclinados
    % Gamma para elementos inclinados alrededor del eje global Y (eje horizontal)
    % Usar precisión extendida con vpa para cada coseno director
    CZ(j) = vpa((nodes(elements(j,3),4) - nodes(elements(j,2),4)) / L(j), 2);
    cz = CZ(j);
    CY(j) = vpa((nodes(elements(j,3),3) - nodes(elements(j,2),3)) / L(j), 2);
    cy = CY(j);
    CX(j) = vpa((nodes(elements(j,3),2) - nodes(elements(j,2),2)) / L(j), 2);
    cx = CX(j);
    
    % Calcular CXY con precisión extendida
    CXY(j) = vpa(sqrt(CX(j)^2 + CY(j)^2), 2);
    cxy = CXY(j);

    cosB = cx/cxy;
    sinB = cy/cxy;
    R_beta = [  cosB    0       sinB;
                0       1       0;
                -sinB   0       cosB];

    % Gamma para elementos inclinados alrededor del eje global Z (eje horizontal)
    cosG = cxy;
    sinG = cz;
    R_gamma = [ cosG    sinG    0;
                -sinG   cosG    0;
                0       0       1];
    
    % Determinamos si el elemento es una columna (vertical)
    if abs(cx) <= 1e-3 && abs(cy) <= 1e-3 && abs(cz) >= 0.99
        % Criterio para elementos tipo columna
        % Construimos la matriz gamma para columna
        gammaColumna = [0   cz  0 ;
                        -cz 0   0;
                        0   0   1];
        
        % Ensamblar la matriz LT para columna
        LT = [gammaColumna zeros(3,9);
              zeros(3,3) gammaColumna zeros(3,6);
              zeros(3,6) gammaColumna zeros(3,3);
              zeros(3,9) gammaColumna];
        
        % Asignar las matrices de transformación
        T_gamma = LT;
        T_beta  = LT;

    elseif cxy <= 1e-3
        % Criterio para elementos horizontales (vigas)
        gamma = [0   cz  0 ;
                -cz 0   0;
                0   0   1];
        LT = [gamma zeros(3,9);
              zeros(3,3) gamma zeros(3,6);
              zeros(3,6) gamma zeros(3,3);
              zeros(3,9) gamma];
        
        % Asignar las matrices de transformación
        T_gamma = LT;
        T_beta  = LT;
        
    else
        % Matrices de transformación para elementos inclinados
        T_gamma = [R_gamma zeros(3,9);
                   zeros(3,3) R_gamma zeros(3,6);
                   zeros(3,6) R_gamma zeros(3,3);
                   zeros(3,9) R_gamma];
                        
        T_beta = [R_beta zeros(3,9);
                  zeros(3,3) R_beta zeros(3,6);
                  zeros(3,6) R_beta zeros(3,3);
                  zeros(3,9) R_beta];
    end
end


