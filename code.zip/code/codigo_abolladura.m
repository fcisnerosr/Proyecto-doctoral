        % Código de abolladura
        index = find(num_de_ele_long(:,1) == i);
        long_elem_a_danar = num_de_ele_long(index,2);
        prop_geom_mat = cell2mat(prop_geom); espesor_elem_a_danar = prop_geom_mat(no_elemento_a_danar(i),10);
        D(i) = prop_geom_mat(no_elemento_a_danar(i),8);
        L_D(i) = long_elem_a_danar;
        z_s(i) = dano_porcentaje(i) * D(i) / 100;
        Nseg = 1000;
        lim = 0.003;
        t(i) = espesor_elem_a_danar;
        R(i) = 0.5 * D(i) - (0.5*t(i));
        A1(i) = pi * D(i)^2 * 0.25;
        D_interior(i) = D(i) - (t(i)*2);
        A2(i) = pi * D_interior(i)^2 * 0.25;
        A_d(i) = A1(i) - A2(i); % Área con daño
        j(i) = prop_geom_mat(no_elemento_a_danar(i),5);

        if dano_porcentaje(i) > 50
            fprintf('\n********************************************************** \n')
            fprintf('***La abolladura no puede ser más del 50%% del diámetro**** \n')
            fprintf('********************************************************** \n\n')
            error('La abolladura excede el 50%% del diámetro. La ejecución se detiene.')
        end

%     % [] = momento_inercia_abolladura(caso_dano, index, num_de_ele_long, long_elem_a_danar, prop_geom_mat, prop_geom, espesor_elem_a_danar, no_elemento_a_danar, D, L_D, z_s, dano_porcentaje, Nseg, lim, t, R, A1, D_interior, A2, A_d, j);
%
%         Slong = 5;
%         x = 0;
%         for j = 1:Slong % Inicio del segundo for
%             x = x + L_d(i)/Slong;
%             V(j) = x/L_d(i);
%             Vz_s(j) = z_s(i) * sin(pi*V(j));
%         end % Fin del segundo for
%         Vz_s = Vz_s(1:end-1);
%
%         % Ciclo para el cálculo de cada momento de inercia en cada sección de abolladura
%         for p = 1:length(Vz_s) % Inicio del tercer for
%             % Datos de abolladura
%             P = 2*pi*R(i);
%             z_i = R(i) - Vz_s(p);
%             z_dent = z_i + R(i);
%             theta = acosd(z_i/R(i));
%             theta = 2*theta;
%             cuerda = sqrt(R(i)^2 - z_i^2);
%             cuerda = 2*cuerda;
%             L1 = theta * pi/180 * R(i);
%             L2 = L1;
%             delta = L2 - cuerda;
%             delta = 0.5 * delta;
%             % Gráfica de sección abollada y sin daño
%             Circ = zeros(Nseg, 2, 2); % Matriz de ceros donde ir incluyendo los valores del círculo
%             Lseg = P / Nseg; % Longitud (perímetro) discretizado
%             Alpha = 0 : 360 / Nseg : 360; % Diferentes valores de PI discretizados
%
%             % Cálculo de curva Z del círculo dañado
%             for j = 1 : Nseg + 1 % Inicio del cuarto for
%                 % Círculo sin daño
%                 Yi = R(i) * cosd(Alpha(j)); % Altura de circunferencia
%                 Zi = R(i) * sind(Alpha(j)); % Anchura de circunferencia
%                 Circ(j, 1, 1) = Yi; % Almacenamiento de valores de la altura de circunferencia
%                 Circ(j, 1, 2) = Zi; % Almacenamiento de valores de la anchura de circunferencia
%                 % Círculo con daño
%                 if Alpha(j) > 90 && Alpha(j) < 270 % Inicio del tercer if
%                     Sig = -1;
%                 else
%                     Sig = 1;
%                 end % Fin del tercer if
%                 if Zi > z_i % Inicio del cuarto if
%                     Circ(j, 2, 1) = Circ(j-1, 2, 1) - Lseg; % Lseg = Longitud (perímetro) discretizado
%                     Circ(j, 2, 2) = z_i;
%                 else
%                     Yi = R(i) * cosd(Alpha(j)); % Altura de circunferencia sin daño (solo para traer el dato)
%                     Zi = R(i) * sind(Alpha(j)); % Anchura de circunferencia sin daño (solo para traer el dato)
%                     Circ(j, 2, 1) = Yi + delta * sin(((pi/2) / (z_dent)) * (Zi + R(i))) * Sig;
%                     Circ(j, 2, 2) = Zi;
%                 end % Fin del cuarto if
%             end % Fin del cuarto for
%
%             % Cálculo de la longitud de la curva inferior
%             for w = 1:Nseg % Inicio del quinto for
%                 if Cir(w,2,2) < z_i && Circ(w,2,1) < 0 % Inicio del quinto if
%                     V_z(w) = Circ(w,2,2);
%                     V_y(w) = Circ(w,2,1);
%                 end % Fin del quinto if
%             end % Fin del quinto for
%             for w = 1:length(V_z)-1 % Inicio del sexto for
%                 if V_y(w) ~= 0 % Inicio del sexto if
%                     Li = sqrt((V_y(w+1) - V_y(w))^2 + (V_z(w+1) - V_z(w))^2);
%                     L_c(w) = Li;
%                 end % Fin del sexto if
%             end % Fin del sexto for
%             L_c = sum(L_c); % Suma de las longitudes
%             L_c = 2 * L_c;
%
%             ec = L_c + cuerda + 2*delta;
%             error = abs(P-ec);
%             kj = 1;
%             kx = 5;
%
%             while error > lim % Inicio del primer while
%                 delta = delta - lim;
%                 ec = L_c + cuerda + 2*delta;
%                 error = abs(P-ec);
%                 V_error(kj) = error;
%                 kj = kj+1;
%                 if kj > kx && V_error(2) > V_error(1) % Inicio del séptimo if
%                     while error > lim % Inicio del segundo while
%                         delta = delta + lim;
%                         ec = L_c + cuerda + 2*delta;
%                         error = abs(P-ec);
%                         V_error(kj) = error;
%                         kj = kj+1;
%                     end % Fin del segundo while
%                 end % Fin del séptimo if
%             end % Fin del primer while
%
%             Circ = zeros(Nseg, 2, 2); % Matriz de ceros donde ir incluyendo los valores del círculo
%             Lseg = P/Nseg; % Longitud (perímetro) discretizado
%             Alpha = 0 : 360 / Nseg : 360; % Diferentes valores de PI discretizados
%
%             for w = 1 : Nseg + 1 % Inicio del séptimo for
%                 Yi = R(i) * cosd(Alpha(w)); % Altura de circunferencia
%                 Zi = R(i) * sind(Alpha(w)); % Anchura de circunferencia
%                 Circ(w, 1, 1) = Yi; % Almacenamiento de valores de la altura de circunferencia
%                 Circ(w, 1, 2) = Zi; % Almacenamiento de valores de la anchura de circunferencia
%                 if Alpha(w) > 90 && Alpha(w) < 270 % Inicio del octavo if
%                     Sig = -1;
%                 else
%                     Sig = 1;
%                 end % Fin del octavo if
%                 if Zi > z_i % Inicio del noveno if
%                     Circ(w, 2, 1) = Circ(w, 2, 1) - Lseg; % Lseg = Longitud (perímetro) discretizado
%                     Circ(w, 2, 2) = z_i;
%                 else
%                     Yi = R(i) * cosd(Alpha(w)); % Altura de circunferencia sin daño
%                     Zi = R(i) * sind(Alpha(w)); % Anchura de circunferencia sin daño
%                     Circ(w, 2, 1) = Yi + delta * sin(((pi/2) / (z_dent)) * (Zi + R(i))) * Sig;
%                     Circ(w, 2, 2) = Zi;
%                 end % Fin del noveno if
%             end % Fin del séptimo for
%             % Cálculo de centroide
%             c_y = 0;
%             c_z = mean(Circ(:,2,2));
%
%             % Cálculo de momentos de inercia
%             j = 1;
%             for ii = 1 : Nseg + 1
%                 Vy_I(j) = Circ(j,2,1);
%                 Vz_I(j) = Circ(j,2,2);
%                 j = j+1;
%                 if Circ(j,2,2) == z_i
%                     break
%                 end
%             end
%             Vz_Ic = Vz_I;
%             Vy_Ic = Vy_I;
%
%             k = 1;
%             for ii = 1 : length(Vz_Ic)-1
%                 L_I(ii) = (((Vz_Ic(ii+1)) - Vz_Ic(ii))^2 + ((Vy_Ic(ii+1)) - Vy_Ic(ii))^2 )^0.5;
%                 V_longy_I(ii) = Vy_Ic(k) - Vy_Ic(k+1);
%                 V_ang_I(ii) = acosd(V_longy_I(ii)/L_I(ii));
%                 k = k+1;
%                 if ii == 1
%                     dy_I(ii) = (L_I(ii)*sind(V_ang_I(ii)) * 0.5) + (c_z*-1);
%                     dz_I(ii) = Circ(ii,2,1) - (L_I(ii)*cosd(V_ang_I(ii)) * 0.5);
%                 else
%                     dy_I(ii) = Circ(ii,2,2) + (L_I(ii)*sind(V_ang_I(ii)) * 0.5 + (c_z*-1));
%                     dz_I(ii) = Circ(ii,2,1) - (L_I(ii)*cosd(V_ang_I(ii)) * 0.5);
%                 end
%             end
%
%             for ii = 1:length(V_ang_I)
%                 Iy_I(ii) = 1/12 * L_I(ii) * t(i)^3;
%                 Iz_I(ii) = 1/12 * L_I(ii)^3 * t(i);
%                 Iy_prima_I(ii) = ((Iy_I(ii) + Iz_I(ii)) * 0.5) + (((Iy_I(ii) - Iz_I(ii))* 0.5) * cosd(2*V_ang_I(ii)));
%                 Iz_prima_I(ii) = ((Iy_I(ii) + Iz_I(ii)) * 0.5) - (((Iy_I(ii) - Iz_I(ii))* 0.5) * cosd(2*V_ang_I(ii)));
%                 A_I(ii) = L_I(ii) * t(i); % Área de cada elemento diferencial
%             end
%
%             % Cuadrante II
%             Alpha = 0: 2*pi/Nseg : 2*pi;
%             j = 1;
%             for ii = 1 : Nseg
%                 y_uni = cos(Alpha);
%                 z_uni = sin(Alpha);
%                 j = j+1;
%                 if sign(y_uni(j)) == -1 && z_uni(j) < 1 && Circ(j,2,2) < z_i
%                     Vy_II(j) = Circ(j,2,1);
%                     Vz_II(j) = Circ(j,2,2);
%                 end
%                 if Circ(j,2,2) < 0
%                     break
%                 end
%             end
%             Vz_II(:,length(Vz_II)) = [];
%             j = 1;
%             r = 1;
%             for ii = 1:length(Vz_II)
%                 if Vz_II(ii) ~= 0 & Vy_II(ii) ~= 0
%                     Vz_IIc(j) = horzcat(Vz_II(ii));
%                     Vy_IIc(j) = horzcat(Vy_II(ii));
%                     j = j+1;
%                 else
%                     r = r + 1;
%                 end
%             end
%             k = 1;
%             for ii = 1 : (length(Vz_IIc)-1)
%                 L_II(ii) = (((Vz_IIc(ii+1)) - Vz_IIc(ii))^2 + ((Vy_IIc(ii+1)) - Vy_IIc(ii))^2 )^0.5;
%                 V_longy_II(ii) = Vy_IIc(k+1) - Vy_IIc(k);
%                 V_ang_II(ii) = acosd(-V_longy_II(ii)/L_II(ii));
%                 k = k+1;
%                 dy_II(ii) = Circ(r,2,2) - L_II(ii)*sind(V_ang_II(ii)) * 0.5 + (c_z*-1);
%                 dz_II(ii) = Circ(r,2,1) - L_II(ii)*cosd(V_ang_II(ii)) * 0.5;
%                 r = r+1;
%             end
%             for ii = 1:length(V_ang_II)
%                 Iy_II(ii) = 1/12 * L_II(ii) * t(i)^3;
%                 Iz_II(ii) = 1/12 * L_II(ii)^3 * t(i);
%                 Iy_prima_II(ii) = ((Iy_II(ii) + Iz_II(ii)) * 0.5) + (((Iy_II(ii) - Iz_II(ii))* 0.5) * cosd(2*V_ang_II(ii)));
%                 Iz_prima_II(ii) = ((Iy_II(ii) + Iz_II(ii)) * 0.5) - (((Iy_II(ii) - Iz_II(ii))* 0.5) * cosd(2*V_ang_II(ii)));
%                 A_II(ii) = L_II(ii) * t(i); % Área de cada elemento diferencial
%             end
%
%             % Cuadrante III
%             j = 1;
%             for ii = 1 : Nseg
%                 y_uni = cos(Alpha);
%                 z_uni = sin(Alpha);
%                 j = j+1;
%                 if sign(y_uni(j)) == -1 && sign(z_uni(j)) == -1
%                     Vy_III(j) = Circ(j,2,1);
%                     Vz_III(j) = Circ(j,2,2);
%                 end
%                 if sign(y_uni(j)) == 0
%                     break
%                 end
%             end
%             j = 1;
%             for ii = 1:length(Vz_III)
%                 if Vz_III(ii) ~= 0
%                     Vy_IIIc(j) = horzcat(Vy_III(ii));
%                     Vz_IIIc(j) = horzcat(Vz_III(ii));
%                     j = j+1;
%                 end
%             end
%             k = 1;
%             r = r+1;
%             for ii = 1 : (length(Vz_IIIc)-1)
%                 L_III(ii) = (((Vz_IIIc(ii+1)) - Vz_IIIc(ii))^2 + ((Vy_IIIc(ii+1)) - Vy_IIIc(ii))^2 )^0.5;
%                 V_longy_III(ii) = Vy_IIIc(k+1) - Vy_IIIc(k);
%                 V_ang_III(ii) = 180 - acosd(-V_longy_III(ii)/L_III(ii));
%                 k = k+1;
%                 dy_III(ii) = Circ(r,2,2) - (L_III(ii)*sind(V_ang_III(ii)) * 0.5) - c_z;
%                 dz_III(ii) = Circ(r,2,1) + (L_III(ii)*cosd(V_ang_III(ii)) * 0.5);
%                 r = r+1;
%             end
%             for ii = 1:length(V_ang_III)
%                 Iy_III(ii) = 1/12 * L_III(ii) * t(i)^3;
%                 Iz_III(ii) = 1/12 * L_III(ii)^3 * t(i);
%                 Iy_prima_III(ii) = ((Iy_III(ii) + Iz_III(ii)) * 0.5) + ((Iy_III(ii) - (Iz_III(ii))* 0.5) * cosd(2*V_ang_III(ii)));
%                 Iz_prima_III(ii) = ((Iy_III(ii) + Iz_III(ii)) * 0.5) - ((Iy_III(ii) - (Iz_III(ii))* 0.5) * cosd(2*V_ang_III(ii)));
%                 A_III(ii) = L_III(ii) * t(i); % Área de cada elemento diferencial
%             end
%
%             % Cuadrante IV
%             for ii = 1 : Nseg+1
%                 y_uni = cos(Alpha);
%                 z_uni = sin(Alpha);
%                 if sign(y_uni(ii)) == 1 && sign(z_uni(ii)) == -1
%                     Vy_IV(ii) = Circ(ii,2,1);
%                     Vz_IV(ii) = Circ(ii,2,2);
%                 end
%             end
%             j = 1;
%             for ii = 1:length(Vz_IV)
%                 if Vz_IV(ii) ~= 0
%                     Vy_IVc(j) = horzcat(Vy_IV(ii));
%                     Vz_IVc(j) = horzcat(Vz_IV(ii));
%                     j = j+1;
%                 end
%             end
%             Vy_IVc(:,length(Vy_IVc)+1) = [delta + R(i)];
%             Vz_IVc(:,length(Vz_IVc)+1) = [0];
%             k = 1;
%             r = r+1;
%             for ii = 1 : (length(Vz_IVc)-1)
%                 L_IV(ii) = (((Vz_IVc(ii+1)) - Vz_IVc(ii))^2 + ((Vy_IVc(ii+1)) - Vy_IVc(ii))^2 )^0.5;
%                 V_longy_IV(ii) = Vy_IVc(k+1) - Vy_IVc(k);
%                 V_ang_IV(ii) = 180 - acosd(-V_longy_IV(ii)/L_IV(ii));
%                 k = k+1;
%                 dy_IV(ii) = Circ(r,2,2) + (L_IV(ii)*sind(V_ang_IV(ii)) * 0.5) - c_z;
%                 dz_IV(ii) = Circ(r,2,1) + (L_IV(ii)*cosd(V_ang_IV(ii)) * 0.5);
%                 r = r+1;
%             end
%             for ii = 1:length(V_ang_IV)
%                 Iy_IV(ii) = 1/12 * L_IV(ii) * t(i)^3;
%                 Iz_IV(ii) = 1/12 * L_IV(ii)^3 * t(i);
%                 Iy_prima_IV(ii) = ((Iy_IV(ii) + Iz_IV(ii)) * 0.5) + (((Iy_IV(ii) - Iz_IV(ii))* 0.5) * cosd(2*V_ang_IV(ii)));
%                 Iz_prima_IV(ii) = ((Iy_IV(ii) + Iz_IV(ii)) * 0.5) - (((Iy_IV(ii) - Iz_IV(ii))* 0.5) * cosd(2*V_ang_IV(ii)));
%                 A_IV(ii) = L_IV(ii) * t(i); % Área de cada elemento diferencial
%             end
%
%             dy = horzcat(dy_I, dy_II, dy_III, dy_IV);
%             dz = horzcat(dz_I, dz_II, dz_III, dz_IV);
%             Iy_prima = horzcat(Iy_prima_I, Iy_prima_II, Iy_prima_III, Iy_prima_IV);
%             Iz_prima = horzcat(Iz_prima_I, Iz_prima_II, Iz_prima_III, Iz_prima_IV);
%             VA = horzcat(A_I, A_II, A_III, A_IV);
%             for ii = 1 : length(dy)-1
%                 Iy_t = Iy_prima(ii) + (VA(ii) * dy.^2);
%                 Iz_t = Iz_prima(ii) + (VA(ii) * dz.^2);
%             end
%
%             L_ach = cuerda + 2*delta;
%             Iy_ach = 1/12 * L_ach * t(i)^3;
%             Iz_ach = 1/12 * L_ach^3 * t(i);
%             A_ach = L_ach*t(i);
%             d_acha = z_i + (c_z*-1);
%             Iy_achatada_centro = Iy_ach + (A_ach * d_acha^2);
%             Iz_achatada_centro = Iz_ach;
%
%             Iy_t_damaged = sum(Iy_t) + Iy_achatada_centro;
%             Iz_t_damaged = sum(Iz_t) + Iz_achatada_centro;
%
%             R_ext(i) = 0.5*D(i);
%             I_ext = pi/4 * R_ext(i)^4;
%             R_int(i) = (0.5*D(i)) - t(i);
%             I_int = pi/4 * (R_int(i))^4;
%             I_undamaged = I_ext - I_int;
%             Dif_y = (Iy_t_damaged - I_undamaged);
%             Porcentaje_reduccion_y = Dif_y*100 / I_undamaged;
%             Dif_z = (Iz_t_damaged - I_undamaged);
%             Porcentaje_reduccion_z = Dif_z*100 / I_undamaged;
%
%             VIy(p) = Iy_t_damaged;
%             VIz(p) = Iz_t_damaged;
%
%             clearvars -except Long D t L_d R A_d A G J E z_s Lseg Nseg x V Vz_s i L P p pi z_i z_dent theta cuerda L1 L2 delta Circ Yi Zi Alpha Sig lim VIy VIz I_undamaged Slong prop_geom t_corro t_d D_d R_d A1_d R_interior_d A2_d A_d long_elem_con_dano hoja_excel datos_para_long elementos_y_long no_elemento_a_danar elem_con_dano_long_NE index ceros_agregar mat_zero ke_d R_ext_d I_ext_d I_int_d I_d archivo_excel tirante tiempo d_agua densidad_crec pathfile caso_dano dano_porcentaje coordenadas vxz conectividad matriz_restriccion matriz_cell_secciones masas_en_cada_nodo M_cond NE IDmax NEn elements nodes damele eledent Iy Iz ID KG KGtu vigas_long brac_long col_long num_de_ele_long f_AA_d
%
%         end % Fin del ciclo for que va iterando sobre cada sección longitudinal del elemento i (elemento tubular con daño)
%
%         VIy = horzcat(I_undamaged,VIy,I_undamaged); % en mm^4
%         VIz = horzcat(I_undamaged,VIz,I_undamaged); % en mm^4
%         x_f = 0 : L_d/Slong : L_d;
%
%         grado = 4;
%         poly_y = polyfit(x_f, VIy, grado);
%
%         ec_y_03_03 = @(x) x.^2 ./ ((E(i))*(poly_y(1)* x .^4 + poly_y(2)* x .^3 + poly_y(3)* x .^2 + poly_y(4)* x .^1 + + poly_y(5)));
%         ec_y_05_05 = @(x) 1 ./ ((E(i))*(poly_y(1)* x .^4 + poly_y(2)* x .^3 + poly_y(3)* x .^2 + poly_y(4)* x .^1 + + poly_y(5)));
%
%         poly_z = polyfit(x_f, VIz, grado);
%         ec_z_02_02 = @(x) x.^2 ./ ((E(i))*(poly_z(1)* x .^4 + poly_z(2)* x .^3 + poly_z(3)* x .^2 + poly_z(4)* x .^1 + + poly_z(5)));
%         ec_z_06_06 = @(x) 1 ./ ((E(i))*(poly_z(1)* x .^4 + poly_z(2)* x .^3 + poly_z(3)* x .^2 + poly_z(4)* x .^1 + + poly_z(5)));
%
%         ec_y_03_05 = @(x) -x ./ ((E(i))*(poly_y(1)* x .^4 + poly_y(2)* x .^3 + poly_y(3)* x .^2 + poly_y(4)* x .^1 + + poly_y(5)));
%         ec_y_05_03 = @(x) -x ./ ((E(i))*(poly_y(1)* x .^4 + poly_y(2)* x .^3 + poly_y(3)* x .^2 + poly_y(4)* x .^1 + + poly_y(5)));
%         ec_y_02_06 = @(x) x ./ ((E(i))*(poly_z(1)* x .^4 + poly_z(2)* x .^3 + poly_z(3)* x .^2 + poly_z(4)* x .^1 + + poly_z(5)));
%         ec_y_06_02 = @(x) x ./ ((E(i))*(poly_z(1)* x .^4 + poly_z(2)* x .^3 + poly_z(3)* x .^2 + poly_z(4)* x .^1 + + poly_z(5)));
%
%         ec_z_06_12 = @(x) -1 ./ ((E(i))*(poly_z(1)* x .^4 + poly_z(2)* x .^3 + poly_z(3)* x .^2 + poly_z(4)* x .^1 + + poly_z(5)));
%         ec_z_06_08 = @(x) (1-x) ./ ((E(i))*(poly_z(1)* x .^4 + poly_z(2)* x .^3 + poly_z(3)* x .^2 + poly_z(4)* x .^1 + + poly_z(5)));
%         ec_y_03_09 = @(x) (x-x.^2) ./ ((E(i))*(poly_y(1)* x .^4 + poly_y(2)* x .^3 + poly_y(3)* x .^2 + poly_y(4)* x .^1 + + poly_y(5)));
%         ec_y_05_11 = @(x) -1 ./ ((E(i))*(poly_y(1)* x .^4 + poly_y(2)* x .^3 + poly_y(3)* x .^2 + poly_y(4)* x .^1 + + poly_y(5)));
%         ec_y_05_09 = @(x) (-1+x) ./ ((E(i))*(poly_y(1)* x .^4 + poly_y(2)* x .^3 + poly_y(3)* x .^2 + poly_y(4)* x .^1 + + poly_y(5)));
%         ec_y_03_11 = @(x) x ./ ((E(i))*(poly_y(1)* x .^4 + poly_y(2)* x .^3 + poly_y(3)* x .^2 + poly_y(4)* x .^1 + + poly_y(5)));
%         ec_z_02_12 = @(x) -x ./ ((E(i))*(poly_z(1)* x .^4 + poly_z(2)* x .^3 + poly_z(3)* x .^2 + poly_z(4)* x .^1 + + poly_z(5)));
%         ec_z_02_08 = @(x) (x-x.^2) ./ ((E(i))*(poly_z(1)* x .^4 + poly_z(2)* x .^3 + poly_z(3)* x .^2 + poly_z(4)* x .^1 + + poly_z(5)));
%
%         f_02_02 = integral(ec_z_02_02, 0, L_d(i));
%         f_03_03 = integral(ec_y_03_03, 0, L_d(i));
%         f_05_05 = integral(ec_y_05_05, 0, L_d(i));
%         f_06_06 = integral(ec_z_06_06, 0, L_d(i));
%         f_02_06 = integral(ec_y_02_06, 0, L_d(i));
%         f_06_02 = integral(ec_y_06_02, 0, L_d(i));
%         f_03_05 = integral(ec_y_03_05, 0, L_d(i));
%         f_05_03 = integral(ec_y_05_03, 0, L_d(i));
%         f_02_08 = integral(ec_z_02_08, 0, L_d(i));
%         f_03_09 = integral(ec_y_03_09, 0, L_d(i));
%         f_05_11 = integral(ec_y_05_11, 0, L_d(i));
%         f_06_12 = integral(ec_z_06_12, 0, L_d(i));
%         f_06_08 = integral(ec_z_06_08, 0, L_d(i));
%         f_05_09 = integral(ec_y_05_09, 0, L_d(i));
%         f_03_11 = integral(ec_y_03_11, 0, L_d(i));
%         f_02_12 = integral(ec_z_02_12, 0, L_d(i));
%
%         f_AA_d(:,:,i) = [
%             L_d(i)/(E(i)*A_d(i)) 0 0 0 0 0; ...
%             0 f_02_02 0 0 0 f_06_02; ...
%             0 0 f_03_03 0 f_05_03 0; ...
%             0 0 0 L_d(i)/(G(i)*j) 0 0; ...
%             0 0 f_03_05 0 f_05_05 0; ...
%             0 f_02_06 0 0 0 f_06_06
%         ];
%
%         T = [
%             -1 0 0 0 0 0; 0 -1 0 0 0 0; 0 0 -1 0 0 0; 0 0 0 -1 0 0; ...
%             0 0 L_d(i) 0 -1 0; 0 -L_d(i) 0 0 0 -1; 1 0 0 0 0 0; ...
%             0 1 0 0 0 0; 0 0 1 0 0 0; 0 0 0 1 0 0; 0 0 0 0 1 0; 0 0 0 0 0 1
%         ];
%         fprintf('Elemento: %d, Daño: %s\n',no_elemento_a_danar(i),caso_dano{i})
%         ke_d(:,:,i) = T * (f_AA_d(:,:,i))^(-1) * T';
%         clearvars VIy VIz
%     end % Fin del bucle for de abolladura
%c
